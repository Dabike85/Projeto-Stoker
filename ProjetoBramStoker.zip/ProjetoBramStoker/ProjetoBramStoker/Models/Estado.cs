﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBramStoker.Models
{
    public class Estado
    {
        public int EstadoID { get; set; }

        public Char UF (2);

        public Char Nome (50);  
        
        public int UsuarioID { get; set; }

    }
}
