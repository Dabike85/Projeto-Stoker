﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TARAX_PROJECT.Models
{
    public class Competicao
    {
        public int UsuarioStatusID { get; set; }
        public char Descricao (100);
    }
}
