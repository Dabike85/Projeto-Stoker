﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBramStoker.Models
{
    public class TipoProduto
    {
        public int TipoID { get; set; }
        public char Descricao { get; set; }
    }
}
