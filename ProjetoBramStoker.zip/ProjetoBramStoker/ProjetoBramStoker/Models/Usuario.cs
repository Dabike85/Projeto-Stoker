﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBramStoker.Models
{
    public class Usuario
    {
        public int UsuarioID { get; set; }
        public int CidadeID { get; set; }
        public DateTime DataCadastro { get; set; }
        public int UsuarioStatusID { get; set; }

        public char Senha (128);
        public char Telefone (20);
        public char CPF (11);
        public char Email (50);
        public char Nome (128);

    }
}
